import 'package:flutter/material.dart';

class ContactPage extends StatefulWidget{
  _ContactPageState createState ()=> new _ContactPageState();
}

class _ContactPageState extends State<ContactPage>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      appBar: AppBar(
        title: new Text('Contact'),
        backgroundColor: Colors.green,
      ),
      body: new Center(
        child: new Text("Page Contact", style: new TextStyle(fontSize: 35.0)),
      ),
    );
  }
}