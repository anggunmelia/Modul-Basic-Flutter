import 'package:flutter/material.dart';

class AboutPage extends StatefulWidget{
  @override
  _AboutPageState createState()=> new _AboutPageState();
}

class _AboutPageState extends State<AboutPage>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      appBar: AppBar(
        title: new Text('About'),
        backgroundColor: Colors.green,
      ),
      body: new Center(
        child: new Text("This Is Page ABout !", style: new TextStyle(fontSize: 35.0)),
      ),
    );
  }
}