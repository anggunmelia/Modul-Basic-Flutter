import 'package:flutter/material.dart';
import 'home.dart';
import 'contact.dart';
import 'about.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Navigation Drawer',
      theme: new ThemeData(
        primarySwatch: Colors.green,
      ), debugShowCheckedModeBanner: false,
      home:  new MyHomePage(),
        routes : <String, WidgetBuilder>{
          '/home': (BuildContext)=> new MyHomePage(),
          '/about': (BuildContext)=> new AboutPage(),
          '/contact':(BuildContext)=>new ContactPage(),
        },
      );
  }
}
