import 'package:flutter/material.dart';
import 'page_widget.dart';

class Home extends StatefulWidget
{
  @override
  State<StatefulWidget>createState(){
    return _HomeState();
  }
}
 class _HomeState extends State<Home>{
  int _currentIndex = 0;
  final List<Widget> _childern = [
    PageWidget (Colors.lightBlueAccent),
    PageWidget(Colors.deepOrange),
    PageWidget(Colors.green)
  ];

  @override
   Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Tab Bar Menu'),
      ),
      body: _childern[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: onTabTapped,
        currentIndex: _currentIndex,
        items: [BottomNavigationBarItem(icon: Icon(Icons.home), title: Text('Home'),
        ),
          BottomNavigationBarItem(icon: Icon(Icons.mail), title: Text('Email'),
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), title: Text('Profile'),
          )
        ],
      ),
    );
  }

  void onTabTapped (int index){
    setState(() {
      _currentIndex = index;
    });
  }

 }