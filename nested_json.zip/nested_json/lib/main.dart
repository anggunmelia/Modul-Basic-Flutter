import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:nestedjson/user_model.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return MaterialApp(
      title: 'Netsed Json',
      home: new DataNestedListPage(),
      theme: ThemeData(primaryColor: Colors.blue),
    );
  }
}

class DataNestedListPage extends StatefulWidget {
  @override
  _DataNestedListPageState createState() => new _DataNestedListPageState();
}

class _DataNestedListPageState extends State<DataNestedListPage> {
  List<UserModel> listModel = [];
  var loading = false;

  Future<Null> getData() async {
    setState(() {
      loading = true;
    });
    /// Note coba belajar cara tracert data seperti ini
    ///  Jika data dari internet kita check fungsi getData nya dulu apakah
    ///  data yang di ambil ada atau tidak
    ///  Kemudian gunakan fungsi safe null agar ketahuan mana yang bermasalah dan enggak
    ///  contoh safe null : nList?.email ?? "n/a"
    ///  Baru check model data jika masih tidak muncul
    ///  Oke cukup segitu sih kalo ada yang ditanyakan boleh sekalian disini aja
    ///  nggak bg, makasih banyak Oke


    final responseData =
        await http.get("https://jsonplaceholder.typicode.com/users");
    //cek status response
    if (responseData.statusCode == 200) {
      final data = jsonDecode(responseData.body);

      log("Check data getting from url");
//      log("Check data ${responseData.body}");
      /// Nah disini udah dapat datanya tinggal di mapping kedalam variable list diatas
      setState(() {
        for (Map i in data) {
          //menambahkan data json ke list
          listModel.add(UserModel.fromJson(i));
        }
        log("Check ambil satu data yang telah di mapping");
        log("Check ambil satu data ${listModel[0]}");

        /// Dibagian sini juga data sudah ada

        loading = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Netsed Json'),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        child: loading
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: listModel.length,
                itemBuilder: (context, i) {
                  final nList = listModel[i];
                  return Container(
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          nList?.name ?? "n/a",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18.0,
                              color: Colors.blue),
                        ),
                        Text(nList?.email ?? "n/a"),
                        Text(nList?.phone ?? "n/a"),
                        Text(nList?.website ?? "n/a"),
                        SizedBox(
                          height: 5.0,
                        ),
                        Text(
                          "Address",
                          style: TextStyle(
                              fontSize: 16.0, fontWeight: FontWeight.bold),
                        ),
                        Text(nList?.address?.street ?? "n/a"), //ada
                        Text(nList?.address?.city?? "n/a"), // ada
                        Text(nList?.address?.suite ?? "n/a"), //tidak ada
                        Text(nList?.address?.zipcode?? "n/a"),
                        SizedBox(
                          height: 5.0,
                        ),
                        Text(
                          "Company",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16.0),
                        ),
                        Text('${nList?.company?.name ?? "n/a"}')
                      ],
                    ),
                  );
                }),
      ),
    );
  }
}
