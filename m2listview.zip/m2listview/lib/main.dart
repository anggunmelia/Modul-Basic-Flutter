import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final title = 'List Apps';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: title,

      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(title),
          backgroundColor: Colors.black12,
        ),

        body: ListView(
          children: [ListTile(leading: Icon(Icons.person), title: Text('Person'),
          ),
            ListTile(leading: Icon(Icons.mail), title: Text('Mail'),
            ),
            ListTile(leading: Icon(Icons.album), title: Text('Album'),
            ),
            ListTile(leading: Icon(Icons.alarm), title: Text('Alarm'),
            ),
            ListTile(leading: Icon(Icons.map), title: Text('Map'),
            ),
          ],
        ),
      ),
    );
  }
}