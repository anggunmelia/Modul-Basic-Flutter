import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    final title = "Horizontal List";
    return MaterialApp(
      title : title,
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.green,
        ),
        body: Container(
        margin: EdgeInsets.symmetric(vertical: 20.0),
        height: 200.0,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [Container(width: 160.0,child: ListTile(leading: Icon (Icons.apps), title: Text('Aplikasi'),),
          ),
          Container(width: 160.0, child: ListTile(leading: Icon(Icons.camera), title: Text('Camera'),
          ),
          ),
          Container(width: 160.0, child: ListTile(leading: Icon(Icons.person), title: Text('Account'),
          ),
          ),
          Container(width: 160.0, child: ListTile(leading: Icon(Icons.home),title: Text('Home'),
          ),
          ),
          ],

        ),
        ),
      )
    );
  }
}
