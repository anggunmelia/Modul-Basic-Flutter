import 'package:flutter/material.dart';

void main() => runApp(HeroApp());

class HeroApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Animasi Transisi With Hero',

      home: MainScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text('Main Screen'),
        backgroundColor:Colors.black,
      ),
      body: GestureDetector(
        child: Hero(
          tag: 'imageHero',
          child: Image.network('https://img.jakpost.net/c/2020/04/22/2020_04_22_93420_1587522578._large.jpg',
          ),
        ),

        onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (_){
            return DetailScreen();
          }));
        },
      ),
    );
  }
}

class DetailScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: GestureDetector(
        child: Center(
          child: Hero(
            tag: 'imageHero',
            child: Image.network('https://img.jakpost.net/c/2020/04/22/2020_04_22_93420_1587522578._large.jpg',
            ),
          ),
        ),

        onTap: ()
        {
          Navigator.pop(context);
        },

      ),
    );
  }
}

class ImageFromAssest extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Page Image From Assest'),
          backgroundColor: Colors.black12,
        ),
        body: Column(children: [Image.asset('image/tom.jpg'), Text('NCT')
        ],
        ),
      ),
    );
  }
}