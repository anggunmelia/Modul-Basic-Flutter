import 'package:beritaapp/detail_bertita.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;



void main ()
{
  runApp(new MaterialApp(
    title: "Berita Apps",
    home: new Home(),
    debugShowCheckedModeBanner: false,
  ));
}

class Home extends StatefulWidget{
  @override
  _HomeState createState()=> new _HomeState();
}

class _HomeState extends State<Home>{
  Future<List>getData()async{
    final response = await http.get("http://192.168.10.64/server_berita/get_berita.php");
    return json.decode(response.body);
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      appBar: AppBar(
        title: new Text("Aplikasi Berita"),
        backgroundColor: Colors.amber,
      ),

      body: new FutureBuilder<List>(
          future: getData(),
          builder: (context, snapshot){
            if(snapshot.hasError)print(snapshot.error);

            return snapshot.hasData
                ?new ItemList(
              list:snapshot.data,
            )
                :new Center(
                  child: new CircularProgressIndicator(),
                );
          },
      ),
    );
  }
}

class ItemList extends StatelessWidget {
  final List list;
  ItemList({this.list});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new ListView.builder(
        itemCount: list==null?0:list.length,
        itemBuilder: (context, i){
          return new Container(
            padding: const EdgeInsets.all(10.0),
            child: new GestureDetector(
              onTap: () => Navigator.of(context).push(
                new MaterialPageRoute(
                    builder: (BuildContext context) => new Detail(list:list, index:i,)
                )
              ),
              child: new Card(

                child: new ListTile(
                  title:  new Text(list[i]['judul_berita'], style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.blue),),
                  subtitle: new Text("Tanggal : ${list[i]['tgl_berita']}"),
                  trailing: new Image.network('http://192.168.10.64/server_berita/gambar/'+
                      list[i]['gbr_berita'],
                      fit: BoxFit.cover,
                      height: 60.0,
                      width: 60.0,
                  ),
                ),
              ),
            ),
          );
        },
    );
  }
}