import 'package:flutter/material.dart';

class Detail extends StatefulWidget{
  List list;
  int index;
  Detail({this.index, this.list});
  @override
  _DetailState createState()=> _DetailState();
}

class _DetailState extends State<Detail>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Scaffold(
      appBar: AppBar(
        title: new Text("${widget.list[widget.index]['judul_berita']}"),
        backgroundColor: Colors.blue,
      ),

      body: new ListView(
        children:<Widget> [
          new Image.network(
            "http://192.168.10.64/server_berita/gambar/"+widget.list[widget.index]['gbr_berita']),
          new Container(
            padding: const EdgeInsets.all(32.0),
            child: new Row(
              children: [
                new Expanded(
                    child:new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        new Container(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: new Text(
                            "judul : "+widget.list[widget.index]['judul_berita'],
                              style: new TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                          ),
                        ),

                        new Text(
                          "Tanggal : "+widget.list[widget.index]['tgl_berita'],
                          style: new TextStyle(
                          color: Colors.grey[500],
                        ),
                        ),
                      ],
                    ),
                ),

                new Icon((Icons.star),
                  color: Colors.red[500],
                ),
              ],
            ),
          ),

          new Container(
            padding: const EdgeInsets.all(32.0),
            child: new Text(widget.list[widget.index]['isi_berita'],
                softWrap: true,),
          )
        ],
      ),
    );
  }
}