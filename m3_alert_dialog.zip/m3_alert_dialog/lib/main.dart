import 'package:flutter/material.dart';
import 'package:alert_dialog/alert_dialog.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notife Widget Alert Dialog',
      home: Scaffold(
        appBar: AppBar(

        ),
        body: Center(
          child: FlatButton(
            child: Text('Alert Dialog'),
            onPressed: ()
            {
              return alert(
                context, title: Text('Alert'),
                content: Text('It Is Fun !'),
                textOK: Text('Yes'),
              );
            },
          ),
        ),
      )
    );
  }
}
