class Contact{
  String name;
  DateTime dob;
  String phone = '';
  String email = '';
  String favoriteColor = '';

}