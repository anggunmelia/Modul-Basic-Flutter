import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class Todo{
  final String title;
  final String description;

  Todo (this.title, this.description);
}

void main() {
  runApp(MaterialApp(
    title: 'Kirim Data Page',
    debugShowCheckedModeBanner: false,
    home: TodosScreen(
      todos:List.generate(10, (i) => Todo('Judul Berita $i', 'Silahkan Isi Berita Anda Sendiri $i',
      ),
      ),
    ),
  ));
}

class TodosScreen extends StatelessWidget{
  final List<Todo>todos;
  TodosScreen({Key key, @required this.todos}):super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('List Berita'),
        backgroundColor: Colors.blue,
      ),
      body: ListView.builder(
          itemCount: todos.length,
          itemBuilder: (context,index){
        return ListTile(
        title: Text (todos[index].title),
        onTap:(){
          Navigator.push(
          context,
          MaterialPageRoute(
          builder:(contex)=>DetailScreen(todo:todos[index]),
          ),
          );
    },
    );
    },
      ),
    );
  }
}

class DetailScreen extends StatelessWidget{
  final Todo todo;

  DetailScreen({Key key, @required this.todo}):super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text(todo.title),
        backgroundColor: Colors.blue,
      ),

      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(todo.description),
      ),
    );
  }
}



