import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Snackbar App',
      home: Scaffold(
        backgroundColor: Colors.teal,
        appBar: AppBar(
          actions: [new IconButton(icon: new Icon(Icons.home, color: Colors.white), onPressed: ()
          {
            Fluttertoast.showToast(msg: "Tombol Home", toastLength: Toast.LENGTH_SHORT, backgroundColor: Colors.black, textColor: Colors.white);
          },
          ),],
          title: Text('Snackbar App'),
          backgroundColor: Colors.pinkAccent,
          leading: new IconButton(icon: new Icon (Icons.add_location, color: Colors.black12,), onPressed: ()
          {
            Navigator.push(context, MaterialPageRoute(builder: (context)=>SnackbarPage()));
          }
          ),
        ),

        body: SnackbarPage(),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: 0,

          items: [
            BottomNavigationBarItem(icon: new Icon(Icons.home), title :new Text('Home'),),
            BottomNavigationBarItem(icon: new Icon(Icons.mail), title : new Text('Message'),),
            BottomNavigationBarItem(icon: new Icon(Icons.person), title : new Text('Profile'),),
          ],
        ),
      ),
    );
  }
}

class SnackbarPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: RaisedButton(
        onPressed: () {

          final snackBar=SnackBar(
            content: Text('Yes, ini adalah contoh snackbar'),
            action: SnackBarAction(
              label: 'Undo',
              onPressed: () {
                // some code to undo the change!
              },
            ),
          );
          Scaffold.of(context).showSnackBar(snackBar);
        },
        child: new Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,children:[new Icon(Icons.add_a_photo, color: Colors.green[900],size: 40.0),
          new Icon(Icons.dashboard, color: Colors.green[900],size: 40.0),
          new Icon(Icons.alarm, color: Colors.green[900],size: 40.0)
        ],
        ),


        textColor: Colors.pinkAccent,
      ),
    );
  }
}
